package advocate.com.advocate_app.service;

import advocate.com.advocate_app.entity.*;
import advocate.com.advocate_app.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;

@Service
public class CaseEventService {

    @Autowired
    private CaseEventRepository caseEventRepository;

    @Autowired
    private AdvocateRepository advocateRepository;

    @Autowired
    private CaseRepository caseRepository;

    @Autowired
    private NotificationService notificationService; // ✅ Added for notifications

    // ✅ Create new event (and trigger notification)
    public CaseEventEntity createEvent(String advocateEmail, CaseEventEntity event) {
        Advocate advocate = advocateRepository.findByEmail(advocateEmail)
                .orElseThrow(() -> new RuntimeException("Advocate not found"));

        CaseEntity caseEntity = caseRepository.findById(event.getCaseEntity().getId())
                .orElseThrow(() -> new RuntimeException("Case not found"));

        event.setAdvocate(advocate);
        event.setCaseEntity(caseEntity);
        event.setNotified(false);

        CaseEventEntity savedEvent = caseEventRepository.save(event);

        // ✅ Create notification automatically when event is added
        String message = "New " + event.getEventType() + " scheduled for case: "
                + caseEntity.getCaseTitle() + " on " + event.getDate();

        notificationService.createNotification(message, advocate);

        return savedEvent;
    }

    // ✅ Get all events for logged-in advocate
    public List<CaseEventEntity> getMyEvents(String advocateEmail) {
        Advocate advocate = advocateRepository.findByEmail(advocateEmail)
                .orElseThrow(() -> new RuntimeException("Advocate not found"));
        return caseEventRepository.findByAdvocate(advocate);
    }

    // ✅ Get events for a particular date (like today)
    public List<CaseEventEntity> getEventsByDate(String advocateEmail, LocalDate date) {
        Advocate advocate = advocateRepository.findByEmail(advocateEmail)
                .orElseThrow(() -> new RuntimeException("Advocate not found"));
        return caseEventRepository.findByAdvocateAndDate(advocate, date);
    }

    // ✅ Get upcoming events (next 7 days)
    public List<CaseEventEntity> getUpcomingEvents(String advocateEmail) {
        Advocate advocate = advocateRepository.findByEmail(advocateEmail)
                .orElseThrow(() -> new RuntimeException("Advocate not found"));
        LocalDate today = LocalDate.now();
        LocalDate nextWeek = today.plusDays(7);
        return caseEventRepository.findUpcomingEvents(advocate, today, nextWeek);
    }

    // ✅ Delete event (and optionally notify advocate)
    public void deleteEvent(String advocateEmail, Long eventId) {
        Advocate advocate = advocateRepository.findByEmail(advocateEmail)
                .orElseThrow(() -> new RuntimeException("Advocate not found"));

        CaseEventEntity event = caseEventRepository.findById(eventId)
                .orElseThrow(() -> new RuntimeException("Event not found"));

        if (!event.getAdvocate().getId().equals(advocate.getId())) {
            throw new RuntimeException("Unauthorized delete attempt.");
        }

        caseEventRepository.delete(event);

        // Optional: Notify advocate of deletion
        String message = "Event deleted: " + event.getTitle() + " (" + event.getEventType() + ")";
        notificationService.createNotification(message, advocate);
    }

    // ✅ Helper: Auto-delete past events (optional)
    public void autoCleanOldEvents() {
        List<CaseEventEntity> allEvents = caseEventRepository.findAll();
        LocalDate today = LocalDate.now();
        for (CaseEventEntity e : allEvents) {
            if (e.getDate().isBefore(today.minusDays(30))) {
                caseEventRepository.delete(e);
            }
        }
    }
}
