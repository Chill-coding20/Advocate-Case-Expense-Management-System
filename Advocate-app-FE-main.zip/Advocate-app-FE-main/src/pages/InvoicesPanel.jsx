import React from "react";

function InvoicesPanel({ invoices }) {
  return (
    <div className="panel">
      <h3 className="panel-title">Invoices</h3>
      <ul className="panel-list">
        <li className="panel-item">✅ Paid: ₹{invoices.paid}</li>
        <li className="panel-item">⌛ Unpaid: ₹{invoices.unpaid}</li>
        <li className="panel-item">⚠️ Overdue: ₹{invoices.overdue}</li>
      </ul>
    </div>
  );
}

export default InvoicesPanel;
