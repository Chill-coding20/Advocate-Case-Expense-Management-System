package advocate.com.advocate_app.controller;

import advocate.com.advocate_app.entity.Advocate;
import advocate.com.advocate_app.security.JwtUtil;
import advocate.com.advocate_app.service.AdvocateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/advocates")
@CrossOrigin(origins = "http://localhost:5173")
public class AdvocateController {

    @Autowired
    private AdvocateService advocateService;

    @PostMapping("/signup")
    public Map<String, String> signup(@RequestBody Advocate advocate) {
        advocateService.registerUser(advocate);
        return Map.of("message", "User registered successfully!");
    }

    @PostMapping("/login")
    public Map<String, String> login(@RequestBody Map<String, String> loginData) {
        String email = loginData.get("email");
        String password = loginData.get("password");

        boolean success = advocateService.checkLogin(email, password);
        if (success) {
            String token = JwtUtil.generateToken(email);
            return Map.of("token", token, "message", "Login Successful!");
        } else {
            return Map.of("error", "Invalid email or password!");
        }
    }
}
