package advocate.com.advocate_app.repository;

import advocate.com.advocate_app.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface CaseEventRepository extends JpaRepository<CaseEventEntity, Long> {

    // ✅ All events of a specific advocate
    List<CaseEventEntity> findByAdvocate(Advocate advocate);

    // ✅ Events for a specific date (e.g., today)
    @Query("SELECT e FROM CaseEventEntity e WHERE e.advocate = :advocate AND e.date = :date")
    List<CaseEventEntity> findByAdvocateAndDate(@Param("advocate") Advocate advocate,
                                                @Param("date") LocalDate date);

    // ✅ Upcoming events within a date range (used in dashboard or reminders)
    @Query("SELECT e FROM CaseEventEntity e WHERE e.advocate = :advocate AND e.date BETWEEN :startDate AND :endDate ORDER BY e.date ASC")
    List<CaseEventEntity> findUpcomingEvents(@Param("advocate") Advocate advocate,
                                             @Param("startDate") LocalDate startDate,
                                             @Param("endDate") LocalDate endDate);

    // ✅ NEW — Fetch all events happening today or tomorrow (used by NotificationScheduler)
    @Query("SELECT e FROM CaseEventEntity e WHERE e.date BETWEEN :today AND :tomorrow")
    List<CaseEventEntity> findEventsForTodayAndTomorrow(@Param("today") LocalDate today,
                                                        @Param("tomorrow") LocalDate tomorrow);
}
