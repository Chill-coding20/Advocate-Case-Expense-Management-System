package advocate.com.advocate_app.repository;

import advocate.com.advocate_app.entity.Client;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;
import java.util.Optional;

public interface ClientRepository extends JpaRepository<Client, Long> {

    Optional<Client> findByEmail(String email);

    // ✅ Fetch only non-deleted clients
    @Query("SELECT c FROM Client c WHERE c.deleted = false")
    List<Client> findAllActive();

    // ✅ Fetch only deleted clients
    @Query("SELECT c FROM Client c WHERE c.deleted = true")
    List<Client> findAllArchived();

    // ✅ Search non-deleted clients
    @Query("SELECT c FROM Client c WHERE c.deleted = false AND " +
            "(LOWER(c.name) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(c.email) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(c.phone) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    List<Client> searchActiveClients(String keyword);
}
