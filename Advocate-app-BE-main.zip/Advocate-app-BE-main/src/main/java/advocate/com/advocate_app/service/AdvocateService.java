package advocate.com.advocate_app.service;

import advocate.com.advocate_app.entity.Advocate;
import advocate.com.advocate_app.repository.AdvocateRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdvocateService {

    @Autowired
    private AdvocateRepository advocateRepository;

    public Advocate registerUser(Advocate advocate) {
        return advocateRepository.save(advocate);
    }

    public boolean checkLogin(String email, String password) {
        return advocateRepository.findByEmail(email)
                .map(advocate -> advocate.getPassword().equals(password))
                .orElse(false);
    }
}
