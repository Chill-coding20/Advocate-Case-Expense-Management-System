import React, { useState, useEffect } from "react";
import axios from "axios";
import "../assets/styles/Clients.css";

function Clients() {
  const [clients, setClients] = useState([]);
  const [showArchived, setShowArchived] = useState(false);
  const [newClient, setNewClient] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
  });
  const [showModal, setShowModal] = useState(false);
  const [editClientId, setEditClientId] = useState(null);
  const [errorMessage, setErrorMessage] = useState("");
  const [searchKeyword, setSearchKeyword] = useState("");
  const token = localStorage.getItem("token");

  useEffect(() => {
    if (!token) {
      setErrorMessage("Please login first.");
    } else {
      fetchClients();
    }
  }, [token, showArchived]);

  const fetchClients = async (keyword = "") => {
    try {
      let url;
      if (showArchived) {
        url = "http://localhost:8080/api/clients/archived";
      } else if (keyword.trim()) {
        url = `http://localhost:8080/api/clients/search?keyword=${encodeURIComponent(keyword)}`;
      } else {
        url = "http://localhost:8080/api/clients/my-clients";
      }

      const response = await axios.get(url, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setClients(response.data);
      setErrorMessage("");
    } catch (error) {
      console.error("Error fetching clients:", error);
      setErrorMessage(error.response?.data || "Failed to fetch clients.");
    }
  };

  const handleSearch = (e) => {
    const keyword = e.target.value;
    setSearchKeyword(keyword);
    fetchClients(keyword);
  };

  const handleChange = (e) => {
    setNewClient({ ...newClient, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editClientId) {
        await axios.put(
          `http://localhost:8080/api/clients/update/${editClientId}`,
          newClient,
          { headers: { Authorization: `Bearer ${token}` } }
        );
      } else {
        await axios.post(
          "http://localhost:8080/api/clients/create",
          newClient,
          { headers: { Authorization: `Bearer ${token}` } }
        );
      }
      setNewClient({ name: "", email: "", phone: "", address: "" });
      setShowModal(false);
      fetchClients();
    } catch (error) {
      console.error("Error saving client:", error);
      setErrorMessage(error.response?.data || "Failed to save client.");
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Archive this client?")) return;
    try {
      await axios.delete(`http://localhost:8080/api/clients/delete/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      fetchClients();
    } catch (error) {
      console.error("Error deleting client:", error);
      setErrorMessage(error.response?.data || "Failed to delete client.");
    }
  };

  const handleRestore = async (id) => {
    try {
      await axios.put(`http://localhost:8080/api/clients/restore/${id}`, {}, {
        headers: { Authorization: `Bearer ${token}` },
      });
      fetchClients();
    } catch (error) {
      console.error("Error restoring client:", error);
      setErrorMessage(error.response?.data || "Failed to restore client.");
    }
  };

  return (
    <div className="clients-container">
      <div className="clients-header">
        <h2>{showArchived ? "Archived Clients" : "My Clients"}</h2>

        <div className="header-actions">
          <input
            type="text"
            placeholder="🔍 Search by name, email, or phone"
            value={searchKeyword}
            onChange={handleSearch}
            className="search-bar"
          />
          <button onClick={() => { setShowModal(true); setEditClientId(null); }}>
            Add New Client
          </button>
          <button onClick={() => setShowArchived(!showArchived)}>
            {showArchived ? "🔙 Back to Active" : "🗄️ View Archived"}
          </button>
        </div>
      </div>

      {errorMessage && <p className="error-message">{errorMessage}</p>}

      {/* Modal */}
      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <h3>{editClientId ? "Edit Client" : "Add New Client"}</h3>
            <form className="client-form" onSubmit={handleSubmit}>
              <input name="name" placeholder="Full Name" value={newClient.name} onChange={handleChange} required />
              <input name="email" type="email" placeholder="Email" value={newClient.email} onChange={handleChange} required />
              <input name="phone" placeholder="Phone Number" value={newClient.phone} onChange={handleChange} required />
              <textarea name="address" placeholder="Address" value={newClient.address} onChange={handleChange} />
              <div className="modal-buttons">
                <button type="submit">{editClientId ? "Update Client" : "Save Client"}</button>
                <button type="button" className="close-btn" onClick={() => setShowModal(false)}>Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="clients-table">
        {clients.length === 0 ? (
          <p>No clients found.</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Name</th><th>Email</th><th>Phone</th><th>Address</th><th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {clients.map((c) => (
                <tr key={c.id}>
                  <td>{c.name}</td><td>{c.email}</td><td>{c.phone}</td><td>{c.address}</td>
                  <td>
                    {showArchived ? (
                      <button onClick={() => handleRestore(c.id)}>♻️ Restore</button>
                    ) : (
                      <>
                        <button onClick={() => { setNewClient(c); setEditClientId(c.id); setShowModal(true); }}>Edit</button>
                        <button onClick={() => handleDelete(c.id)}>Archive</button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

export default Clients;
