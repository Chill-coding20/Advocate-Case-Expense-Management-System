package advocate.com.advocate_app.service;

import advocate.com.advocate_app.entity.Advocate;
import advocate.com.advocate_app.entity.CaseEventEntity;
import advocate.com.advocate_app.entity.NotificationEntity;
import advocate.com.advocate_app.repository.CaseEventRepository;
import advocate.com.advocate_app.repository.NotificationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class NotificationScheduler {

    @Autowired
    private CaseEventRepository caseEventRepository;

    @Autowired
    private NotificationRepository notificationRepository;

    /**
     * ✅ Runs automatically every day at 7:00 AM
     * Format: second minute hour day month weekday
     * Example: "0 0 7 * * *" means 7:00 AM daily
     */
    @Scheduled(cron = "0 0 7 * * *")
    public void generateDailyNotifications() {
        LocalDate today = LocalDate.now();
        LocalDate tomorrow = today.plusDays(1);

        System.out.println("🔔 [Scheduler] Running Notification Check for: " + today);

        // ✅ Fetch only relevant events (today & tomorrow)
        List<CaseEventEntity> events =
                caseEventRepository.findEventsForTodayAndTomorrow(today, tomorrow);

        for (CaseEventEntity event : events) {
            try {
                if (event.isNotified()) continue; // Skip already notified events

                LocalDate eventDate = event.getDate();
                Advocate advocate = event.getAdvocate();

                String message;
                if (eventDate.isEqual(today)) {
                    message = "Reminder: " + event.getEventType() +
                            " today for Case " + event.getCaseEntity().getCaseNumber() +
                            " (" + (event.getTime() != null ? event.getTime() : "Time not set") + ")";
                } else {
                    message = "Upcoming: " + event.getEventType() +
                            " tomorrow for Case " + event.getCaseEntity().getCaseNumber() +
                            " (" + (event.getTime() != null ? event.getTime() : "Time not set") + ")";
                }

                // ✅ Create new notification
                NotificationEntity notification = new NotificationEntity();
                notification.setAdvocate(advocate);
                notification.setMessage(message);
                notification.setReadStatus(false);
                notification.setCreatedAt(java.time.LocalDateTime.now());

                notificationRepository.save(notification);

                // ✅ Mark event as notified to avoid duplicate reminders
                event.setNotified(true);
                caseEventRepository.save(event);

                System.out.println("✅ Notification created for advocate: "
                        + advocate.getEmail() + " | " + message);

            } catch (Exception ex) {
                System.err.println("⚠️ Error processing event ID: " + event.getId() + " — " + ex.getMessage());
            }
        }
    }
}
