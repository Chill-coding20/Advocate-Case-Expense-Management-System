package advocate.com.advocate_app.service;

import advocate.com.advocate_app.entity.Advocate;
import advocate.com.advocate_app.entity.CaseEntity;
import advocate.com.advocate_app.entity.Client;
import advocate.com.advocate_app.entity.Expense;
import advocate.com.advocate_app.repository.AdvocateRepository;
import advocate.com.advocate_app.repository.CaseRepository;
import advocate.com.advocate_app.repository.ExpenseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class ExpenseService {

    private final ExpenseRepository expenseRepository;
    private final AdvocateRepository advocateRepository;
    private final CaseRepository caseRepository;

    @Autowired
    public ExpenseService(ExpenseRepository expenseRepository,
                          AdvocateRepository advocateRepository,
                          CaseRepository caseRepository) {
        this.expenseRepository = expenseRepository;
        this.advocateRepository = advocateRepository;
        this.caseRepository = caseRepository;
    }

    // ✅ Create Expense
    public Expense createExpense(String advocateEmail, Expense expense) {
        Advocate advocate = advocateRepository.findByEmail(advocateEmail)
                .orElseThrow(() -> new RuntimeException("Advocate not found"));
        expense.setAdvocate(advocate);

        // Default payment date = today if null
        if (expense.getPaymentDate() == null) {
            expense.setPaymentDate(new Date());
        }

        if ("GENERAL".equalsIgnoreCase(expense.getExpenseType())) {
            expense.setCaseEntity(null);
            expense.setClient(null);
            return expenseRepository.save(expense);
        }

        if (expense.getCaseEntity() == null || expense.getCaseEntity().getId() == null) {
            throw new RuntimeException("Case must be selected for client case expenses.");
        }

        CaseEntity caseEntity = caseRepository.findById(expense.getCaseEntity().getId())
                .orElseThrow(() -> new RuntimeException("Case not found"));

        expense.setCaseEntity(caseEntity);
        Client client = caseEntity.getClient();
        if (client != null) expense.setClient(client);

        Expense saved = expenseRepository.save(expense);
        updateCaseFinancials(caseEntity);
        return saved;
    }

    // ✅ Update Expense
    public Expense updateExpense(String advocateEmail, Long id, Expense updatedExpense) {
        Advocate advocate = advocateRepository.findByEmail(advocateEmail)
                .orElseThrow(() -> new RuntimeException("Advocate not found"));
        Expense existing = expenseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Expense not found"));

        if (!existing.getAdvocate().getId().equals(advocate.getId()))
            throw new RuntimeException("Unauthorized update attempt");

        existing.setTitle(updatedExpense.getTitle());
        existing.setAmount(updatedExpense.getAmount());
        existing.setCategory(updatedExpense.getCategory());
        existing.setDescription(updatedExpense.getDescription());
        existing.setPaymentMode(updatedExpense.getPaymentMode());
        existing.setPaymentStatus(updatedExpense.getPaymentStatus());
        existing.setReferenceNumber(updatedExpense.getReferenceNumber());
        existing.setPaymentDate(
                updatedExpense.getPaymentDate() != null ? updatedExpense.getPaymentDate() : new Date()
        );
        existing.setExpenseType(
                updatedExpense.getExpenseType() != null ? updatedExpense.getExpenseType() : "CLIENT_CASE"
        );

        if (updatedExpense.getCaseEntity() != null && updatedExpense.getCaseEntity().getId() != null) {
            CaseEntity caseEntity = caseRepository.findById(updatedExpense.getCaseEntity().getId())
                    .orElseThrow(() -> new RuntimeException("Case not found"));
            existing.setCaseEntity(caseEntity);
            existing.setClient(caseEntity.getClient());
            expenseRepository.save(existing);
            updateCaseFinancials(caseEntity);
        } else {
            existing.setCaseEntity(null);
            existing.setClient(null);
            expenseRepository.save(existing);
        }

        return existing;
    }

    // ✅ Get all Expenses for an Advocate
    public List<Expense> getMyExpenses(String advocateEmail) {
        Advocate advocate = advocateRepository.findByEmail(advocateEmail)
                .orElseThrow(() -> new RuntimeException("Advocate not found"));
        return expenseRepository.findByAdvocate(advocate);
    }

    // ✅ Get Expenses by Case
    public List<Expense> getExpensesByCase(String advocateEmail, Long caseId) {
        Advocate advocate = advocateRepository.findByEmail(advocateEmail)
                .orElseThrow(() -> new RuntimeException("Advocate not found"));
        CaseEntity caseEntity = caseRepository.findById(caseId)
                .orElseThrow(() -> new RuntimeException("Case not found"));
        if (!caseEntity.getAdvocate().getId().equals(advocate.getId()))
            throw new RuntimeException("Unauthorized access to this case's expenses");

        return expenseRepository.findByCaseEntity(caseEntity);
    }

    // ✅ Delete Expense
    public void deleteExpense(String advocateEmail, Long id) {
        Advocate advocate = advocateRepository.findByEmail(advocateEmail)
                .orElseThrow(() -> new RuntimeException("Advocate not found"));
        Expense exp = expenseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Expense not found"));
        if (!exp.getAdvocate().getId().equals(advocate.getId()))
            throw new RuntimeException("Unauthorized delete attempt");

        CaseEntity caseEntity = exp.getCaseEntity();
        expenseRepository.delete(exp);
        if (caseEntity != null) updateCaseFinancials(caseEntity);
    }

    // ✅ Search
    public List<Expense> searchExpenses(String advocateEmail, String keyword) {
        List<Expense> all = getMyExpenses(advocateEmail);
        if (keyword == null || keyword.isBlank()) return all;
        String key = keyword.toLowerCase();
        return all.stream().filter(exp ->
                (exp.getTitle() != null && exp.getTitle().toLowerCase().contains(key)) ||
                        (exp.getCategory() != null && exp.getCategory().toLowerCase().contains(key)) ||
                        (exp.getPaymentStatus() != null && exp.getPaymentStatus().toLowerCase().contains(key)) ||
                        (exp.getReferenceNumber() != null && exp.getReferenceNumber().toLowerCase().contains(key))
        ).toList();
    }

    // ✅ Update Case Financials
    private void updateCaseFinancials(CaseEntity caseEntity) {
        double totalExpenses = expenseRepository.findByCaseEntity(caseEntity).stream()
                .mapToDouble(e -> e.getAmount() != null ? e.getAmount() : 0.0)
                .sum();

        caseEntity.setTotalExpensesSoFar(totalExpenses);
        Double paid = Optional.ofNullable(caseEntity.getTotalPaidByClient()).orElse(0.0);
        Double agreed = Optional.ofNullable(caseEntity.getTotalClientAgreedAmount()).orElse(0.0);
        caseEntity.setBalanceInAccount(paid - totalExpenses);
        caseEntity.setPendingFromClient(agreed - paid);
        caseRepository.save(caseEntity);
    }

    // ✅ Helper for date conversion
    private LocalDate safeConvert(Date date) {
        try {
            return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        } catch (Exception e) {
            return null;
        }
    }

    // ✅ Today's Expenses (Fixed timezone)
    public Map<String, Object> getTodayExpenses(String advocateEmail) {
        try {
            List<Expense> all = getMyExpenses(advocateEmail);
            LocalDate today = LocalDate.now(ZoneId.systemDefault());
            Date start = Date.from(today.atStartOfDay(ZoneId.systemDefault()).toInstant());
            Date end = Date.from(today.plusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant());

            List<Expense> todayList = all.stream()
                    .filter(e -> e.getPaymentDate() != null &&
                            !e.getPaymentDate().before(start) &&
                            e.getPaymentDate().before(end))
                    .toList();

            double totalAmount = todayList.stream()
                    .mapToDouble(e -> e.getAmount() != null ? e.getAmount() : 0.0)
                    .sum();

            return Map.of(
                    "date", today.toString(),
                    "count", todayList.size(),
                    "totalAmount", totalAmount,
                    "expenses", todayList
            );
        } catch (Exception e) {
            e.printStackTrace();
            return Map.of("error", "Error while fetching today's expenses: " + e.getMessage());
        }
    }

    // ✅ Monthly Report (Grouped by category)
    public Map<String, Object> getMonthlyReport(String advocateEmail, int year, int month) {
        try {
            List<Expense> all = getMyExpenses(advocateEmail);
            List<Expense> filtered = all.stream().filter(e -> {
                LocalDate date = safeConvert(e.getPaymentDate());
                return date != null && date.getYear() == year && date.getMonthValue() == month;
            }).collect(Collectors.toList());

            double total = filtered.stream()
                    .mapToDouble(e -> e.getAmount() != null ? e.getAmount() : 0.0)
                    .sum();

            Map<String, Double> byCategory = filtered.stream()
                    .collect(Collectors.groupingBy(
                            e -> Optional.ofNullable(e.getCategory()).orElse("Uncategorized"),
                            Collectors.summingDouble(e -> e.getAmount() != null ? e.getAmount() : 0.0)
                    ));

            return Map.of(
                    "month", month,
                    "year", year,
                    "totalExpenses", total,
                    "categoryBreakdown", byCategory,
                    "totalCount", filtered.size(),
                    "expenses", filtered
            );
        } catch (Exception e) {
            e.printStackTrace();
            return Map.of("error", "Error while fetching monthly report: " + e.getMessage());
        }
    }
}
