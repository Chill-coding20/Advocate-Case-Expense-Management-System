import { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../assets/styles/Signup.css";
import signuppic from "../assets/images/login.png";
import axios from "axios";

function Signup() {
  const navigate = useNavigate(); 
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    password: "",
    phone: "",
    barCouncilId: "",
    specialization: "",
    experience: "",
    address: ""
  });

  function handleChange(e) {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  }

  async function handleSubmit(e) {
    e.preventDefault();
    console.log("Signup Data (raw):", formData);

    // Convert experience to number
    const submitData = {
      ...formData,
      experience: formData.experience ? Number(formData.experience) : 0
    };

    console.log("Signup Data (to send):", submitData);

    try {
      const response = await axios.post(
        "http://localhost:8080/api/advocates/signup",
        submitData,
        {
          headers: { "Content-Type": "application/json" }
        }
      );
      console.log("✅ Server Response:", response.data);
      alert(response.data.message || "Signup successful!");
      navigate("/login");
    } catch (error) {
      console.error("❌ Error during signup:", error);
      if (error.response) {
        alert(`Signup failed: ${error.response.data.error || "Unknown error"}`);
        console.log("Backend error response:", error.response.data);
        alert('This Email is already registered');
      } else {
        alert("Signup failed! Please try again.");
      }
    }
  }

  return (
    <div className="signup-container">
      <div className="signup-box">
        <div className="signup-left">
          <img src={signuppic} alt="Signup Illustration" />
        </div>
        <div className="signup-right">
          <h2>Advocate Signup</h2>
          <form onSubmit={handleSubmit}>
            <input type="text" name="fullName" placeholder="Full Name" value={formData.fullName} onChange={handleChange} required />
            <input type="email" name="email" placeholder="Email" value={formData.email} onChange={handleChange} required />
            <input type="password" name="password" placeholder="Password" value={formData.password} onChange={handleChange} required />
            <input type="text" name="phone" placeholder="Phone Number (optional)" value={formData.phone} onChange={handleChange} />
            <input type="text" name="barCouncilId" placeholder="Bar Council ID" value={formData.barCouncilId} onChange={handleChange} required />
            <input type="text" name="specialization" placeholder="Specialization (e.g., Civil, Criminal)" value={formData.specialization} onChange={handleChange} />
            <input type="number" name="experience" placeholder="Experience (Years)" value={formData.experience} onChange={handleChange} />
            <textarea name="address" placeholder="Address / Location" value={formData.address} onChange={handleChange} />
            <button type="submit">Sign Up</button>
          </form>
          <p>
            Already have an account?{" "}
            <span className="link" onClick={() => navigate("/login")}>
              Login
            </span>
          </p>
        </div>
      </div>
    </div>
  );
}

export default Signup;
