package advocate.com.advocate_app.repository;

import advocate.com.advocate_app.entity.Advocate;
import advocate.com.advocate_app.entity.CaseEntity;
import advocate.com.advocate_app.entity.Expense;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ExpenseRepository extends JpaRepository<Expense, Long> {

    // ✅ Fetch all expenses for a specific advocate
    List<Expense> findByAdvocate(Advocate advocate);

    // ✅ Fetch all expenses for a specific case
    List<Expense> findByCaseEntity(CaseEntity caseEntity);
}
