package advocate.com.advocate_app.controller;

import advocate.com.advocate_app.entity.Expense;
import advocate.com.advocate_app.security.JwtUtil;
import advocate.com.advocate_app.service.ExpenseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/expenses")
@CrossOrigin(origins = "http://localhost:5173") // ✅ Allow React app
public class ExpenseController {

    private final ExpenseService expenseService;

    @Autowired
    public ExpenseController(ExpenseService expenseService) {
        this.expenseService = expenseService;
    }

    // ✅ Create Expense
    @PostMapping("/create")
    public ResponseEntity<?> createExpense(@RequestHeader("Authorization") String token,
                                           @RequestBody Expense expense) {
        try {
            String email = JwtUtil.extractEmail(token.substring(7));
            Expense saved = expenseService.createExpense(email, expense);
            return ResponseEntity.ok(saved);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body("Error creating expense: " + e.getMessage());
        }
    }

    // ✅ Update Expense
    @PutMapping("/update/{id}")
    public ResponseEntity<?> updateExpense(@RequestHeader("Authorization") String token,
                                           @PathVariable Long id,
                                           @RequestBody Expense expense) {
        try {
            String email = JwtUtil.extractEmail(token.substring(7));
            Expense updated = expenseService.updateExpense(email, id, expense);
            return ResponseEntity.ok(updated);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body("Error updating expense: " + e.getMessage());
        }
    }

    // ✅ Get all expenses
    @GetMapping("/my-expenses")
    public ResponseEntity<?> getMyExpenses(@RequestHeader("Authorization") String token) {
        try {
            String email = JwtUtil.extractEmail(token.substring(7));
            List<Expense> expenses = expenseService.getMyExpenses(email);
            return ResponseEntity.ok(expenses);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body("Error fetching expenses: " + e.getMessage());
        }
    }

    // ✅ Get all expenses by Case ID
    @GetMapping("/case/{caseId}")
    public ResponseEntity<?> getExpensesByCase(@RequestHeader("Authorization") String token,
                                               @PathVariable Long caseId) {
        try {
            String email = JwtUtil.extractEmail(token.substring(7));
            List<Expense> expenses = expenseService.getExpensesByCase(email, caseId);
            return ResponseEntity.ok(expenses);
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error fetching case expenses: " + e.getMessage());
        }
    }

    // ✅ Search expenses
    @GetMapping("/search")
    public ResponseEntity<?> searchExpenses(@RequestHeader("Authorization") String token,
                                            @RequestParam(required = false) String keyword) {
        try {
            String email = JwtUtil.extractEmail(token.substring(7));
            List<Expense> result = expenseService.searchExpenses(email, keyword);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error searching expenses: " + e.getMessage());
        }
    }

    // ✅ Delete Expense
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> deleteExpense(@RequestHeader("Authorization") String token,
                                           @PathVariable Long id) {
        try {
            String email = JwtUtil.extractEmail(token.substring(7));
            expenseService.deleteExpense(email, id);
            return ResponseEntity.ok("Expense deleted successfully");
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error deleting expense: " + e.getMessage());
        }
    }

    // ✅ Today's Expenses Report
    @GetMapping("/today")
    public ResponseEntity<?> getTodayExpenses(@RequestHeader("Authorization") String token) {
        try {
            String email = JwtUtil.extractEmail(token.substring(7));
            Map<String, Object> report = expenseService.getTodayExpenses(email);
            return ResponseEntity.ok(report);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body("Error fetching today's expenses: " + e.getMessage());
        }
    }

    // ✅ Monthly Report
    @GetMapping("/monthly")
    public ResponseEntity<?> getMonthlyReport(@RequestHeader("Authorization") String token,
                                              @RequestParam int year,
                                              @RequestParam int month) {
        try {
            String email = JwtUtil.extractEmail(token.substring(7));
            Map<String, Object> report = expenseService.getMonthlyReport(email, year, month);
            return ResponseEntity.ok(report);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body("Error fetching monthly report: " + e.getMessage());
        }
    }
}
