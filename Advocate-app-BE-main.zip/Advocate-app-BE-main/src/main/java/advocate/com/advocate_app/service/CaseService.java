package advocate.com.advocate_app.service;

import advocate.com.advocate_app.entity.Advocate;
import advocate.com.advocate_app.entity.CaseEntity;
import advocate.com.advocate_app.repository.AdvocateRepository;
import advocate.com.advocate_app.repository.CaseRepository;
import advocate.com.advocate_app.repository.ClientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class CaseService {

    private final CaseRepository caseRepository;
    private final AdvocateRepository advocateRepository;
    private final ClientRepository clientRepository;

    @Autowired
    public CaseService(CaseRepository caseRepository,
                       AdvocateRepository advocateRepository,
                       ClientRepository clientRepository) {
        this.caseRepository = caseRepository;
        this.advocateRepository = advocateRepository;
        this.clientRepository = clientRepository;
    }

    public CaseEntity createCase(String advocateEmail, CaseEntity caseEntity) {
        Advocate advocate = advocateRepository.findByEmail(advocateEmail)
                .orElseThrow(() -> new RuntimeException("Advocate not found"));

        if (caseEntity.getCaseNumber() != null &&
                caseRepository.findByCaseNumber(caseEntity.getCaseNumber()).isPresent()) {
            throw new RuntimeException("Case number already exists: " + caseEntity.getCaseNumber());
        }

        caseEntity.setAdvocate(advocate);

        if (caseEntity.getClient() != null && caseEntity.getClient().getId() != null) {
            caseEntity.setClient(
                    clientRepository.findById(caseEntity.getClient().getId())
                            .orElseThrow(() -> new RuntimeException("Client not found"))
            );
        }

        return caseRepository.save(caseEntity);
    }

    public List<CaseEntity> getMyCases(String advocateEmail) {
        Advocate advocate = advocateRepository.findByEmail(advocateEmail)
                .orElseThrow(() -> new RuntimeException("Advocate not found"));
        return caseRepository.findByAdvocate(advocate);
    }

    public List<CaseEntity> searchCases(String advocateEmail, String keyword) {
        Advocate advocate = advocateRepository.findByEmail(advocateEmail)
                .orElseThrow(() -> new RuntimeException("Advocate not found"));

        List<CaseEntity> allCases = caseRepository.findByAdvocate(advocate);

        return allCases.stream()
                .filter(c -> (keyword == null || keyword.isBlank()) ||
                        (c.getCaseNumber() != null && c.getCaseNumber().toLowerCase().contains(keyword.toLowerCase())) ||
                        (c.getCaseTitle() != null && c.getCaseTitle().toLowerCase().contains(keyword.toLowerCase())) ||
                        (c.getCaseType() != null && c.getCaseType().toLowerCase().contains(keyword.toLowerCase())) ||
                        (c.getCourtLevel() != null && c.getCourtLevel().toLowerCase().contains(keyword.toLowerCase())) ||
                        (c.getStatus() != null && c.getStatus().toLowerCase().contains(keyword.toLowerCase())) ||
                        (c.getClient() != null && (
                                (c.getClient().getName() != null && c.getClient().getName().toLowerCase().contains(keyword.toLowerCase())) ||
                                        (c.getClient().getEmail() != null && c.getClient().getEmail().toLowerCase().contains(keyword.toLowerCase())) ||
                                        (c.getClient().getPhone() != null && c.getClient().getPhone().toLowerCase().contains(keyword.toLowerCase()))
                        )))
                .toList();
    }

    public CaseEntity updateCase(String advocateEmail, Long caseId, CaseEntity updatedCase) {
        Advocate advocate = advocateRepository.findByEmail(advocateEmail)
                .orElseThrow(() -> new RuntimeException("Advocate not found"));

        CaseEntity existingCase = caseRepository.findById(caseId)
                .orElseThrow(() -> new RuntimeException("Case not found"));

        if (!existingCase.getAdvocate().getId().equals(advocate.getId())) {
            throw new RuntimeException("You are not authorized to update this case.");
        }

        existingCase.setCaseNumber(updatedCase.getCaseNumber());
        existingCase.setCaseTitle(updatedCase.getCaseTitle());
        existingCase.setCaseType(updatedCase.getCaseType());
        existingCase.setCourtLevel(updatedCase.getCourtLevel());
        existingCase.setStatus(updatedCase.getStatus());
        existingCase.setAmount(updatedCase.getAmount());
        existingCase.setDescription(updatedCase.getDescription());

        if (updatedCase.getClient() != null && updatedCase.getClient().getId() != null) {
            existingCase.setClient(
                    clientRepository.findById(updatedCase.getClient().getId())
                            .orElseThrow(() -> new RuntimeException("Client not found"))
            );
        } else {
            existingCase.setClient(null);
        }

        return caseRepository.save(existingCase);
    }

    public void deleteCase(String advocateEmail, Long caseId) {
        Advocate advocate = advocateRepository.findByEmail(advocateEmail)
                .orElseThrow(() -> new RuntimeException("Advocate not found"));

        CaseEntity existingCase = caseRepository.findById(caseId)
                .orElseThrow(() -> new RuntimeException("Case not found"));

        if (!existingCase.getAdvocate().getId().equals(advocate.getId())) {
            throw new RuntimeException("You are not authorized to delete this case.");
        }

        caseRepository.delete(existingCase);
    }
}
