package advocate.com.advocate_app.service;

import advocate.com.advocate_app.entity.*;
import advocate.com.advocate_app.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class ClientPaymentService {

    @Autowired
    private ClientPaymentRepository paymentRepository;

    @Autowired
    private AdvocateRepository advocateRepository;

    @Autowired
    private CaseRepository caseRepository;

    // ✅ Create Payment
    public ClientPayment createPayment(ClientPayment payment) {
        if (payment.getCaseEntity() == null || payment.getCaseEntity().getId() == null) {
            throw new RuntimeException("Case ID is required for client payment.");
        }

        CaseEntity caseEntity = caseRepository.findById(payment.getCaseEntity().getId())
                .orElseThrow(() -> new RuntimeException("Case not found."));

        payment.setCaseEntity(caseEntity);
        payment.setClient(caseEntity.getClient());
        payment.setAdvocate(caseEntity.getAdvocate());

        if (payment.getPaymentDate() == null) {
            payment.setPaymentDate(new Date());
        }

        ClientPayment saved = paymentRepository.save(payment);
        updateCaseFinancials(caseEntity);
        return saved;
    }

    // ✅ Get Payments by Case
    public List<ClientPayment> getPaymentsByCase(Long caseId) {
        CaseEntity caseEntity = caseRepository.findById(caseId)
                .orElseThrow(() -> new RuntimeException("Case not found"));
        return paymentRepository.findByCaseEntity(caseEntity);
    }

    // ✅ Today's Summary
    public Map<String, Object> getTodaySummary() {
        LocalDate today = LocalDate.now(ZoneId.systemDefault());
        Date start = Date.from(today.atStartOfDay(ZoneId.systemDefault()).toInstant());
        Date end = Date.from(today.plusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant());

        List<ClientPayment> payments = paymentRepository.findByPaymentDateBetween(start, end);

        double totalAmount = payments.stream()
                .mapToDouble(p -> p.getAmount() != null ? p.getAmount() : 0.0)
                .sum();

        return Map.of(
                "date", today.toString(),
                "totalAmount", totalAmount,
                "totalCount", payments.size(),
                "payments", payments
        );
    }

    // ✅ Monthly Summary
    public Map<String, Object> getMonthlySummary(int year, int month) {
        LocalDate start = LocalDate.of(year, month, 1);
        LocalDate end = start.plusMonths(1);

        Date startDate = Date.from(start.atStartOfDay(ZoneId.systemDefault()).toInstant());
        Date endDate = Date.from(end.atStartOfDay(ZoneId.systemDefault()).toInstant());

        List<ClientPayment> payments = paymentRepository.findByPaymentDateBetween(startDate, endDate);

        double totalAmount = payments.stream()
                .mapToDouble(p -> p.getAmount() != null ? p.getAmount() : 0.0)
                .sum();

        Map<String, Double> byMode = payments.stream()
                .collect(Collectors.groupingBy(
                        p -> Optional.ofNullable(p.getPaymentMode()).orElse("Unknown"),
                        Collectors.summingDouble(p -> p.getAmount() != null ? p.getAmount() : 0.0)
                ));

        return Map.of(
                "year", year,
                "month", month,
                "totalAmount", totalAmount,
                "totalCount", payments.size(),
                "modeBreakdown", byMode,
                "payments", payments
        );
    }

    // ✅ Update case’s financial status
    private void updateCaseFinancials(CaseEntity caseEntity) {
        double totalPayments = paymentRepository.findByCaseEntity(caseEntity).stream()
                .mapToDouble(p -> p.getAmount() != null ? p.getAmount() : 0.0)
                .sum();

        double totalExpenses = caseEntity.getTotalExpensesSoFar() != null
                ? caseEntity.getTotalExpensesSoFar()
                : 0.0;

        caseEntity.setTotalPaidByClient(totalPayments);
        caseEntity.setBalanceInAccount(totalPayments - totalExpenses);

        Double agreed = Optional.ofNullable(caseEntity.getTotalClientAgreedAmount()).orElse(0.0);
        caseEntity.setPendingFromClient(agreed - totalPayments);

        caseRepository.save(caseEntity);
    }
}
