Advocate Case Management System

A full-stack application built with React.js and Spring Boot to help advocates manage cases, clients, expenses, documents, and payments.
The system includes separate dashboards for Advocates and Clients, secure authentication, cloud document storage, and automated fee calculation based on case type and court level.

🚀 Features
Advocate Panel

Manage cases (add, update, delete)

Track case expenses

Maintain client records

Upload documents to cloud

View complete financial details (including commission)

Dashboard with stats, upcoming hearings, and alerts

Client Panel

Login to view case details

See hearing updates, status changes

Access documents uploaded by advocate

View only the total payable amount (commission hidden)

Pricing Logic

Case type + court level determine base fee

Advocate sees full breakdown (base fee + commission)

Client sees only final payable fee

🛠️ Tech Stack
Frontend

React.js

React Router

Axios

TailwindCSS / Material UI

Backend

Java 17+

Spring Boot

Spring Security (JWT)

Spring Data JPA

MySQL / PostgreSQL

Storage

Cloud storage (AWS S3 / Firebase)

📁 Project Structure
Frontend
/src
 ├── components
 ├── pages
 ├── context
 ├── services
 └── App.jsx

Backend
/src/main/java/com/advocateapp
 ├── controller
 ├── service
 ├── repository
 ├── model
 ├── security
 └── AdvocateApplication.java

🔒 Authentication

Implemented using:

JWT Access Tokens

Password hashing

Role-based access (ADVOCATE / CLIENT)

🗂️ API Endpoints
Auth
Method	Endpoint	Description
POST	/auth/register	Register advocate/client
POST	/auth/login	Login + JWT token
Cases
Method	Endpoint	Description
POST	/cases	Create case
GET	/cases	Get all cases
GET	/cases/{id}	Case details
PUT	/cases/{id}	Update
DELETE	/cases/{id}	Delete
Expenses

| POST | /cases/{id}/expenses
| GET | /cases/{id}/expenses

Documents

| POST | /cases/{id}/documents
| GET | /cases/{id}/documents

🗄️ Database Schema (Simplified)
Case
id
title
client_id
case_type
court_level
status
next_hearing_date
base_fee
commission
total_fee

Expense
id
case_id
description
amount
date

Client
id
name
email
phone
password_hash

⚙️ Installation
Backend
cd backend
mvn clean install


Configure application.properties:

spring.datasource.url=jdbc:mysql://localhost:3306/advocate_app
spring.datasource.username=root
spring.datasource.password=YOUR_PASSWORD
jwt.secret=YOUR_SECRET_KEY


Run:

mvn spring-boot:run

Frontend
cd frontend
npm install
npm start

🚀 Deployment

Frontend → Netlify / Vercel

Backend → Render / Railway / AWS

Environment variables stored securely

Cloud bucket for document uploads

📌 Future Improvements

SMS / Email hearing notifications

Auto-generated PDF invoices

Advocate revenue analytics

AI-powered document summarization

📄 License

MIT License.
