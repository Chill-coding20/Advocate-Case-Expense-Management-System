import '../assets/styles/Login.css';
import logpic from '../assets/images/login.png';
import { useNavigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import axios from 'axios';
import { logoutAndRedirect, isTokenExpired } from '../utils/auth.jsx'; // ✅ import

function LoginModule() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({ email: "", password: "" });

  // ✅ Setup global axios interceptor once
  useEffect(() => {
    const interceptor = axios.interceptors.response.use(
      (response) => response,
      (error) => {
        if (error.response && error.response.status === 401) {
          console.warn("Session expired or unauthorized. Logging out...");
          logoutAndRedirect();
        }
        return Promise.reject(error);
      }
    );
    return () => axios.interceptors.response.eject(interceptor);
  }, []);

  function handleChange(e) {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  }

  async function handleSubmit(e) {
    e.preventDefault();
    try {
      const response = await axios.post(
        "http://localhost:8080/api/advocates/login",
        formData,
        { headers: { "Content-Type": "application/json" } }
      );

      if (response.data.token) {
        localStorage.setItem("token", response.data.token);
        localStorage.setItem("email", formData.email);

        alert(response.data.message || "Login successful!");
        navigate("/dashboard");
      } else {
        alert(response.data.error || "Login failed!");
      }
    } catch (error) {
      console.error("❌ Error during login:", error.response || error.message);
      alert("Login failed! Please check your credentials or try again.");
    }
  }

  return (
    <div className="loginpage">
      <div className="login-box justify-content-center d-flex m-5 border border-info">
        <div className="left-box">
          <h1>WELCOME</h1>
          <h2>LOGIN</h2>
          <form onSubmit={handleSubmit}>
            <input
              type="email"
              name="email"
              placeholder="EMAIL"
              value={formData.email}
              onChange={handleChange}
              required
            />
            <input
              type="password"
              name="password"
              placeholder="PASSWORD"
              value={formData.password}
              onChange={handleChange}
              required
            />
            <button type="submit" className="btn btn-outline-danger">Submit</button>
          </form>
        </div>
        <div className="right-box">
          <button className="img-btn button-danger rounded-circle" onClick={() => navigate("/")}>✖</button>
          <img src={logpic} alt="Login" />
        </div>
      </div>
    </div>
  );
}

export default LoginModule;
