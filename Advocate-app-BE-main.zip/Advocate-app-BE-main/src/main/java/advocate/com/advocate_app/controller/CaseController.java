package advocate.com.advocate_app.controller;

import advocate.com.advocate_app.entity.CaseEntity;
import advocate.com.advocate_app.security.JwtUtil;
import advocate.com.advocate_app.service.CaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/cases")
@CrossOrigin(origins = "http://localhost:5173")
public class CaseController {

    private final CaseService caseService;

    @Autowired
    public CaseController(CaseService caseService) {
        this.caseService = caseService;
    }

    @PostMapping("/create")
    public ResponseEntity<?> createCase(@RequestHeader("Authorization") String token,
                                        @RequestBody CaseEntity caseEntity) {
        try {
            String email = JwtUtil.extractEmail(token.substring(7));
            CaseEntity savedCase = caseService.createCase(email, caseEntity);
            return ResponseEntity.ok(savedCase);
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error creating case: " + e.getMessage());
        }
    }

    @GetMapping("/my-cases")
    public ResponseEntity<?> getMyCases(@RequestHeader("Authorization") String token) {
        try {
            String email = JwtUtil.extractEmail(token.substring(7));
            return ResponseEntity.ok(caseService.getMyCases(email));
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error fetching cases: " + e.getMessage());
        }
    }

    @GetMapping("/search")
    public ResponseEntity<?> searchCases(@RequestHeader("Authorization") String token,
                                         @RequestParam(required = false) String keyword) {
        try {
            String email = JwtUtil.extractEmail(token.substring(7));
            return ResponseEntity.ok(caseService.searchCases(email, keyword));
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error searching cases: " + e.getMessage());
        }
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<?> updateCase(@RequestHeader("Authorization") String token,
                                        @PathVariable Long id,
                                        @RequestBody CaseEntity caseEntity) {
        try {
            String email = JwtUtil.extractEmail(token.substring(7));
            return ResponseEntity.ok(caseService.updateCase(email, id, caseEntity));
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error updating case: " + e.getMessage());
        }
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> deleteCase(@RequestHeader("Authorization") String token,
                                        @PathVariable Long id) {
        try {
            String email = JwtUtil.extractEmail(token.substring(7));
            caseService.deleteCase(email, id);
            return ResponseEntity.ok("Case deleted successfully");
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error deleting case: " + e.getMessage());
        }
    }
}
