package advocate.com.advocate_app.repository;

import advocate.com.advocate_app.entity.NotificationEntity;
import advocate.com.advocate_app.entity.Advocate;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface NotificationRepository extends JpaRepository<NotificationEntity, Long> {

    // Get all unread notifications for an advocate
    List<NotificationEntity> findByAdvocateAndReadStatusFalseOrderByCreatedAtDesc(Advocate advocate);
}
