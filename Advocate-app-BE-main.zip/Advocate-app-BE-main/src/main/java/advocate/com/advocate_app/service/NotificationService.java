package advocate.com.advocate_app.service;

import advocate.com.advocate_app.entity.NotificationEntity;
import advocate.com.advocate_app.entity.Advocate;
import advocate.com.advocate_app.repository.NotificationRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class NotificationService {

    private final NotificationRepository notificationRepository;

    public NotificationService(NotificationRepository notificationRepository) {
        this.notificationRepository = notificationRepository;
    }

    // ✅ Create new notification
    public void createNotification(String message, Advocate advocate) {
        NotificationEntity notification = new NotificationEntity(message, advocate);
        notificationRepository.save(notification);
    }

    // ✅ Get unread notifications for an advocate
    public List<NotificationEntity> getUnreadNotifications(Advocate advocate) {
        return notificationRepository.findByAdvocateAndReadStatusFalseOrderByCreatedAtDesc(advocate);
    }

    // ✅ Mark notification as read
    public void markAsRead(Long notificationId) {
        notificationRepository.findById(notificationId).ifPresent(notification -> {
            notification.setReadStatus(true);
            notificationRepository.save(notification);
        });
    }
}
