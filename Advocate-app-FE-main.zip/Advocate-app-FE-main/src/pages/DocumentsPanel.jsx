import React from "react";

function DocumentsPanel({ docs }) {
  return (
    <div className="documents-panel">
      <h3>Documents</h3>
      <ul>
        {docs.map(doc => (
          <li key={doc.id}>
            {doc.name} ({doc.type})
          </li>
        ))}
      </ul>
    </div>
  );
}

export default DocumentsPanel;
