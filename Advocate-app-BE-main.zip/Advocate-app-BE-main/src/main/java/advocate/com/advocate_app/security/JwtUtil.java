package advocate.com.advocate_app.security;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import javax.crypto.spec.SecretKeySpec;
import java.security.Key;
import java.util.Base64;
import java.util.Date;

public class JwtUtil {

    private static final String SECRET = "my_super_secret_key_for_advocate_app_12345";
    private static final long EXPIRATION_TIME = 1000 * 60 * 60 * 24;

    private static final Key key = new SecretKeySpec(
            Base64.getDecoder().decode(Base64.getEncoder().encodeToString(SECRET.getBytes())),
            SignatureAlgorithm.HS256.getJcaName()
    );

    public static String generateToken(String email) {
        return Jwts.builder()
                .setSubject(email)
                .setExpiration(new Date(System.currentTimeMillis() + EXPIRATION_TIME))
                .signWith(key)
                .compact();
    }

    public static String extractEmail(String token) {
        return Jwts.parserBuilder()
                .setSigningKey(key)
                .build()
                .parseClaimsJws(token)
                .getBody()
                .getSubject();
    }
}
