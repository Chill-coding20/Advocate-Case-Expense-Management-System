package advocate.com.advocate_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class AdvocateAppApplication {
    public static void main(String[] args) {
        SpringApplication.run(AdvocateAppApplication.class, args);
        System.out.println("✅ Advocate Application Backend Started Successfully!");
    }
}
