import {Link} from 'react-router-dom'
import hmlogo from '../assets/images/LOGO.png'
import '../assets/styles/Homepage.css'
function Homepage(){
return(
    <>
    <div id='homepage'>
      <br />
        <div className="navbar container text-dark">
                <button className='btn btn-outline-secondary border'><Link to="/" className='navbar-brand 'style={{color:'yellow'}}>HOME</Link></button>
                <button className="btn btn-outline-secondary border"><Link to="/login" className='navbar-brand' style={{color:'yellow'}}>Login</Link></button>
                <button className="btn btn-outline-secondary border"><Link to="/dashboard" className='navbar-brand' style={{color:'yellow'}}>Dashboard</Link></button>
        </div>
        <br />
        <div id='welcomebox'className="container-xl d-flex justify-content-center rounded text-center">
          <div>
          <h1>WELCOME</h1><br />
          <h1>ADVOCATE CASE MANAGEMENT SYSTEM</h1>
          <img src={hmlogo} alt="logo" /><br /><br />
          <h3>CODER:CHILL-CODING</h3>
          <button id='signup' className="btn btn-info border" ><Link to='signup' style={{color:'white'}}>Signup</Link></button><br />
          <span>Already have an account?</span><span id='loginbtn'><Link to='login' style={{color:'yellow'}}>LOGIN</Link></span>
          </div>
        </div>
    </div>
          </>
)
}
export default Homepage