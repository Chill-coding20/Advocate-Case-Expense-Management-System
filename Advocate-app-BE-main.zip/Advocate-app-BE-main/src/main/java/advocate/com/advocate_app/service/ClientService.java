package advocate.com.advocate_app.service;

import advocate.com.advocate_app.entity.Client;
import advocate.com.advocate_app.repository.ClientRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class ClientService {

    private final ClientRepository clientRepository;

    public ClientService(ClientRepository clientRepository) {
        this.clientRepository = clientRepository;
    }

    // ✅ Fetch only active clients
    public List<Client> getAllClients() {
        return clientRepository.findAllActive();
    }

    public Optional<Client> getClientById(Long id) {
        return clientRepository.findById(id).filter(c -> !c.isDeleted());
    }

    public Client addClient(Client client) {
        client.setDeleted(false);
        return clientRepository.save(client);
    }

    public Client updateClient(Long id, Client clientDetails) {
        return clientRepository.findById(id)
                .map(client -> {
                    client.setName(clientDetails.getName());
                    client.setEmail(clientDetails.getEmail());
                    client.setPhone(clientDetails.getPhone());
                    client.setAddress(clientDetails.getAddress());
                    return clientRepository.save(client);
                })
                .orElseThrow(() -> new RuntimeException("Client not found with id " + id));
    }

    // ✅ Soft delete instead of physical delete
    public void deleteClient(Long id) {
        Client client = clientRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Client not found"));
        client.setDeleted(true);
        clientRepository.save(client);
    }

    // ✅ Restore a previously deleted client
    public void restoreClient(Long id) {
        Client client = clientRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Client not found"));
        client.setDeleted(false);
        clientRepository.save(client);
    }

    // ✅ Search only active clients
    public List<Client> searchClients(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return clientRepository.findAllActive();
        }
        return clientRepository.searchActiveClients(keyword.trim());
    }

    // ✅ Fetch archived (soft-deleted) clients
    public List<Client> getArchivedClients() {
        return clientRepository.findAllArchived();
    }
}
