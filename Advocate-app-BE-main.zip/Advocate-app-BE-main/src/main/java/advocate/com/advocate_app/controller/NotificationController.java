package advocate.com.advocate_app.controller;

import advocate.com.advocate_app.entity.Advocate;
import advocate.com.advocate_app.entity.NotificationEntity;
import advocate.com.advocate_app.repository.AdvocateRepository;
import advocate.com.advocate_app.service.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/notifications")
@CrossOrigin(origins = "http://localhost:5173") // ✅ Adjust if needed
public class NotificationController {

    @Autowired
    private NotificationService notificationService;

    @Autowired
    private AdvocateRepository advocateRepository;

    // ✅ Get all unread notifications for the logged-in advocate
    @GetMapping("/unread")
    public ResponseEntity<List<NotificationEntity>> getUnreadNotifications(
            @RequestHeader("Authorization") String token) {
        try {
            // Extract email from JWT token
            String email = advocate.com.advocate_app.security.JwtUtil.extractEmail(token.substring(7));

            Advocate advocate = advocateRepository.findByEmail(email)
                    .orElseThrow(() -> new RuntimeException("Advocate not found"));

            List<NotificationEntity> unreadNotifications =
                    notificationService.getUnreadNotifications(advocate);

            return ResponseEntity.ok(unreadNotifications);

        } catch (Exception e) {
            return ResponseEntity.status(500).build();
        }
    }

    // ✅ Mark a specific notification as read
    @PutMapping("/read/{id}")
    public ResponseEntity<String> markAsRead(@PathVariable Long id) {
        try {
            notificationService.markAsRead(id);
            return ResponseEntity.ok("Notification marked as read");
        } catch (Exception e) {
            return ResponseEntity.status(500)
                    .body("Error marking notification as read: " + e.getMessage());
        }
    }
}
