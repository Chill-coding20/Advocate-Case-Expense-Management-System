package advocate.com.advocate_app.controller;

import advocate.com.advocate_app.entity.Client;
import advocate.com.advocate_app.service.ClientService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/clients")
@CrossOrigin(origins = "http://localhost:5173")
public class ClientController {

    private final ClientService clientService;

    public ClientController(ClientService clientService) {
        this.clientService = clientService;
    }

    @GetMapping("/my-clients")
    public List<Client> getMyClients() {
        return clientService.getAllClients(); // ✅ active clients only
    }

    @GetMapping("/archived")
    public List<Client> getArchivedClients() {
        return clientService.getArchivedClients(); // ✅ archived clients only
    }

    @GetMapping("/{id}")
    public ResponseEntity<Client> getClientById(@PathVariable Long id) {
        return clientService.getClientById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/create")
    public Client createClient(@RequestBody Client client) {
        return clientService.addClient(client);
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<Client> updateClient(@PathVariable Long id, @RequestBody Client client) {
        try {
            return ResponseEntity.ok(clientService.updateClient(id, client));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // ✅ Soft delete instead of permanent delete
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteClient(@PathVariable Long id) {
        clientService.deleteClient(id);
        return ResponseEntity.ok("Client archived successfully (soft deleted).");
    }

    // ✅ Restore endpoint
    @PutMapping("/restore/{id}")
    public ResponseEntity<String> restoreClient(@PathVariable Long id) {
        clientService.restoreClient(id);
        return ResponseEntity.ok("Client restored successfully.");
    }

    @GetMapping("/search")
    public ResponseEntity<List<Client>> searchClients(@RequestParam("keyword") String keyword) {
        List<Client> result = clientService.searchClients(keyword);
        return ResponseEntity.ok(result);
    }
}
