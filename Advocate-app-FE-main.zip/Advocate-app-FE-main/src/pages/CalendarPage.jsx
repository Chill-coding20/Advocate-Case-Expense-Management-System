import React, { useEffect, useState } from "react";
import { Calendar, momentLocalizer, Views } from "react-big-calendar";
import moment from "moment";
import axios from "axios";
import Select from "react-select"; // ✅ new import
import "react-big-calendar/lib/css/react-big-calendar.css";
import "../assets/styles/CalendarPage.css";

const localizer = momentLocalizer(moment);

function CalendarPage() {
  const [events, setEvents] = useState([]);
  const [cases, setCases] = useState([]);
  const [filteredEvents, setFilteredEvents] = useState([]);
  const [currentView, setCurrentView] = useState(Views.MONTH);
  const [currentDate, setCurrentDate] = useState(new Date());
  const [showModal, setShowModal] = useState(false);

  const [newEvent, setNewEvent] = useState({
    title: "",
    eventType: "",
    description: "",
    date: "",
    time: "",
    caseId: "",
  });

  const token = localStorage.getItem("token");

  // ✅ Fetch Cases
  const fetchCases = async () => {
    try {
      const res = await axios.get("http://localhost:8080/api/cases/my-cases", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setCases(res.data || []);
    } catch (err) {
      console.error("Error fetching cases:", err);
    }
  };

  // ✅ Fetch Events
  const fetchEvents = async () => {
    try {
      const res = await axios.get("http://localhost:8080/api/events/my-events", {
        headers: { Authorization: `Bearer ${token}` },
      });

      const formatted = res.data.map((e) => ({
        id: e.id,
        title: `${e.title} (${e.eventType})`,
        start: new Date(`${e.date}T${e.time || "09:00"}`),
        end: new Date(`${e.date}T${e.time || "10:00"}`),
        allDay: false,
        eventType: e.eventType,
        description: e.description,
        caseId: e.caseEntity?.id,
      }));

      setEvents(formatted);
      setFilteredEvents(formatted);
    } catch (err) {
      console.error("Error fetching events:", err);
    }
  };

  useEffect(() => {
    fetchEvents();
    fetchCases();
  }, []);

  const handleChange = (e) => {
    setNewEvent({ ...newEvent, [e.target.name]: e.target.value });
  };

  // ✅ Handle case selection
  const handleCaseSelect = (selectedOption) => {
    setNewEvent({ ...newEvent, caseId: selectedOption ? selectedOption.value : "" });
  };

  // ✅ Add new event
  const handleAddEvent = async (e) => {
    e.preventDefault();
    try {
      await axios.post(
        "http://localhost:8080/api/events/create",
        {
          title: newEvent.title,
          eventType: newEvent.eventType,
          description: newEvent.description,
          date: newEvent.date,
          time: newEvent.time,
          caseEntity: { id: Number(newEvent.caseId) },
        },
        { headers: { Authorization: `Bearer ${token}` } }
      );

      setShowModal(false);
      setNewEvent({
        title: "",
        eventType: "",
        description: "",
        date: "",
        time: "",
        caseId: "",
      });
      fetchEvents();
    } catch (err) {
      console.error("Error adding event:", err);
      alert("Failed to create event!");
    }
  };

  // ✅ Calendar Navigation
  const goToToday = () => setCurrentDate(new Date());
  const goToNext = () => {
    const nextDate =
      currentView === Views.MONTH
        ? moment(currentDate).add(1, "month").toDate()
        : moment(currentDate).add(1, "week").toDate();
    setCurrentDate(nextDate);
  };
  const goToPrev = () => {
    const prevDate =
      currentView === Views.MONTH
        ? moment(currentDate).subtract(1, "month").toDate()
        : moment(currentDate).subtract(1, "week").toDate();
    setCurrentDate(prevDate);
  };
  const changeView = (view) => setCurrentView(view);

  // ✅ Event Color Styling
  const eventStyleGetter = (event) => {
    let backgroundColor = "#1976d2";
    if (event.eventType === "HEARING") backgroundColor = "#e53935";
    else if (event.eventType === "MEETING") backgroundColor = "#43a047";
    else if (event.eventType === "PAYMENT_DUE") backgroundColor = "#ffb300";
    else if (event.eventType === "DOCUMENT") backgroundColor = "#6d4c41";

    return {
      style: {
        backgroundColor,
        color: "#fff",
        borderRadius: "8px",
        padding: "2px 5px",
      },
    };
  };

  // ✅ Prepare case options for react-select
  const caseOptions = cases.map((c) => ({
    value: c.id,
    label: `${c.caseNumber || "N/A"} — ${c.client?.name || "Unknown"}`,
  }));

  return (
    <div className="calendar-container">
      <div className="calendar-header">
        <h2>📅 Case Events Calendar</h2>
        <div style={{ display: "flex", gap: "10px" }}>
          <button onClick={() => setShowModal(true)}>➕ Add Event</button>
          <button onClick={goToPrev}>⬅️ Prev</button>
          <button onClick={goToToday}>📍 Today</button>
          <button onClick={goToNext}>➡️ Next</button>
          <button onClick={() => changeView(Views.WEEK)}>🗓️ Week</button>
          <button onClick={() => changeView(Views.MONTH)}>📆 Month</button>
          <button onClick={() => changeView(Views.AGENDA)}>📋 Agenda</button>
        </div>
      </div>

      {/* ✅ Calendar */}
      <Calendar
        localizer={localizer}
        events={filteredEvents}
        startAccessor="start"
        endAccessor="end"
        style={{ height: 600 }}
        eventPropGetter={eventStyleGetter}
        date={currentDate}
        view={currentView}
        onNavigate={setCurrentDate}
        onView={setCurrentView}
      />

      {/* ✅ Add Event Modal */}
      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <h3>Add New Event</h3>
            <form onSubmit={handleAddEvent} className="event-form">
              <input
                name="title"
                placeholder="Event Title"
                value={newEvent.title}
                onChange={handleChange}
                required
              />
              <select
                name="eventType"
                value={newEvent.eventType}
                onChange={handleChange}
                required
              >
                <option value="">Select Type</option>
                <option value="HEARING">Hearing</option>
                <option value="MEETING">Client Meeting</option>
                <option value="PAYMENT_DUE">Payment Due</option>
                <option value="DOCUMENT">Document Filing</option>
              </select>

              <input
                type="date"
                name="date"
                value={newEvent.date}
                onChange={handleChange}
                required
              />
              <input
                type="time"
                name="time"
                value={newEvent.time}
                onChange={handleChange}
              />

              {/* ✅ Searchable Case Dropdown */}
              <label>Select Case:</label>
              <Select
                options={caseOptions}
                value={caseOptions.find((opt) => opt.value === newEvent.caseId) || null}
                onChange={handleCaseSelect}
                placeholder="Search by Case or Client Name..."
                isSearchable
                styles={{
                  control: (base) => ({
                    ...base,
                    borderRadius: "8px",
                    borderColor: "#ccc",
                    boxShadow: "none",
                    "&:hover": { borderColor: "#40e0d0" },
                  }),
                }}
              />

              <textarea
                name="description"
                placeholder="Description"
                value={newEvent.description}
                onChange={handleChange}
              ></textarea>

              <div className="modal-buttons">
                <button type="submit">💾 Save</button>
                <button type="button" onClick={() => setShowModal(false)}>
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default CalendarPage;
