package advocate.com.advocate_app.repository;

import advocate.com.advocate_app.entity.Advocate;
import advocate.com.advocate_app.entity.CaseEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;
import java.util.Optional;

public interface CaseRepository extends JpaRepository<CaseEntity, Long> {

    List<CaseEntity> findByAdvocate(Advocate advocate);

    Optional<CaseEntity> findByCaseNumber(String caseNumber);

    @Query("SELECT c FROM CaseEntity c LEFT JOIN c.client cl " +
            "WHERE (:keyword IS NULL OR " +
            "LOWER(c.caseNumber) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(c.caseTitle) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(c.caseType) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(c.courtLevel) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(c.status) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(cl.name) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(cl.email) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
            "LOWER(cl.phone) LIKE LOWER(CONCAT('%', :keyword, '%')) )")
    List<CaseEntity> searchCases(@Param("keyword") String keyword);
}
