import React, { useState, useEffect } from "react";
import axios from "axios";
import Select from "react-select";
import "../assets/styles/Cases.css";

function Cases() {
  const [cases, setCases] = useState([]);
  const [clients, setClients] = useState([]);
  const [newCase, setNewCase] = useState({
    caseNumber: "",
    caseTitle: "",
    caseType: "",
    courtLevel: "",
    status: "",
    amount: "",
    description: "",
    clientId: "",
  });
  const [showModal, setShowModal] = useState(false);
  const [editCaseId, setEditCaseId] = useState(null);
  const [errorMessage, setErrorMessage] = useState("");
  const [caseNumberError, setCaseNumberError] = useState("");
  const [searchKeyword, setSearchKeyword] = useState("");
  const token = localStorage.getItem("token");

  useEffect(() => {
    if (!token) {
      setErrorMessage("Please login first.");
    } else {
      fetchCases();
      fetchClients();
    }
  }, [token]);

  // ---------------- FETCH CASES ----------------
  const fetchCases = async () => {
    try {
      const response = await axios.get("http://localhost:8080/api/cases/my-cases", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setCases(response.data);
      setErrorMessage("");
    } catch (error) {
      console.error("Error fetching cases:", error);
      setErrorMessage(error.response?.data || "Failed to fetch cases.");
    }
  };

  // ---------------- FETCH CLIENTS ----------------
  const fetchClients = async () => {
    try {
      const response = await axios.get("http://localhost:8080/api/clients/my-clients", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setClients(response.data);
    } catch (error) {
      console.error("Error fetching clients:", error);
      setErrorMessage("Failed to fetch clients. Check server/CORS.");
    }
  };

  // ---------------- SEARCH CASES ----------------
  const handleSearch = async (e) => {
    const keyword = e.target.value;
    setSearchKeyword(keyword);
    if (!keyword.trim()) {
      fetchCases();
      return;
    }
    try {
      const response = await axios.get(
        `http://localhost:8080/api/cases/search?keyword=${keyword}`,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setCases(response.data);
    } catch (error) {
      console.error("Error searching cases:", error);
      setErrorMessage(error.response?.data || "Search failed.");
    }
  };

  // ---------------- FORM INPUT CHANGE ----------------
  const handleChange = (e) => {
    const { name, value } = e.target;
    setNewCase({ ...newCase, [name]: value });

    if (name === "caseNumber") {
      if (value.length !== 16) {
        setCaseNumberError("Case Number must be exactly 16 digits.");
      } else {
        setCaseNumberError("");
      }
    }
  };

  // ---------------- CREATE/UPDATE CASE ----------------
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!token) {
      setErrorMessage("Please login first.");
      return;
    }
    if (!newCase.clientId) {
      setErrorMessage("Please choose a client for this case.");
      return;
    }
    if (newCase.caseNumber.length !== 16) {
      setCaseNumberError("Case Number must be exactly 16 digits.");
      return;
    }

    const caseToSend = {
      ...newCase,
      amount: newCase.amount ? parseFloat(newCase.amount) : 0,
      client: { id: Number(newCase.clientId) },
    };

    try {
      if (editCaseId) {
        await axios.put(
          `http://localhost:8080/api/cases/update/${editCaseId}`,
          caseToSend,
          { headers: { Authorization: `Bearer ${token}` } }
        );
        setEditCaseId(null);
      } else {
        await axios.post(
          "http://localhost:8080/api/cases/create",
          caseToSend,
          { headers: { Authorization: `Bearer ${token}` } }
        );
      }

      setNewCase({
        caseNumber: "",
        caseTitle: "",
        caseType: "",
        courtLevel: "",
        status: "",
        amount: "",
        description: "",
        clientId: "",
      });
      setShowModal(false);
      setCaseNumberError("");
      fetchCases();
      setErrorMessage("");
    } catch (error) {
      console.error("Error saving case:", error);
      setErrorMessage(error.response?.data || "Failed to save case.");
    }
  };

  // ---------------- EDIT CASE ----------------
  const handleEdit = (caseData) => {
    setNewCase({
      caseNumber: caseData.caseNumber || "",
      caseTitle: caseData.caseTitle || "",
      caseType: caseData.caseType || "",
      courtLevel: caseData.courtLevel || "",
      status: caseData.status || "",
      amount: caseData.amount || "",
      description: caseData.description || "",
      clientId: caseData.client?.id ? String(caseData.client.id) : "",
    });
    setEditCaseId(caseData.id);
    setShowModal(true);
  };

  // ---------------- DELETE CASE ----------------
  const handleDelete = async (id) => {
    if (!token) {
      setErrorMessage("Please login first.");
      return;
    }
    try {
      await axios.delete(`http://localhost:8080/api/cases/delete/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      fetchCases();
      setErrorMessage("");
    } catch (error) {
      console.error("Error deleting case:", error);
      setErrorMessage(error.response?.data || "Failed to delete case.");
    }
  };

  return (
    <div className="cases-container">
      <h2>My Cases</h2>
      {errorMessage && <p className="error-message">{errorMessage}</p>}

      {/* ✅ Top Actions */}
      <div className="cases-top-actions">
        <button
          onClick={() => {
            setShowModal(true);
            setEditCaseId(null);
          }}
        >
          Add New Case
        </button>

        {/* ✅ Search bar */}
        <input
          type="text"
          placeholder="🔍 Search by case number, client name, or email"
          value={searchKeyword}
          onChange={handleSearch}
          className="search-bar"
        />
      </div>

      {/* ✅ Modal */}
      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <h3>{editCaseId ? "Edit Case" : "Add New Case"}</h3>
            <form className="case-form" onSubmit={handleSubmit}>
              <input
                type="text"
                name="caseNumber"
                placeholder="Case Number (16 digits)"
                value={newCase.caseNumber}
                onChange={handleChange}
                required
              />
              {caseNumberError && (
                <p className="error-message">{caseNumberError}</p>
              )}

              <input
                type="text"
                name="caseTitle"
                placeholder="Case Title"
                value={newCase.caseTitle}
                onChange={handleChange}
                required
              />
              <input
                type="text"
                name="caseType"
                placeholder="Case Type"
                value={newCase.caseType}
                onChange={handleChange}
                required
              />

              <select
                name="courtLevel"
                value={newCase.courtLevel}
                onChange={handleChange}
                required
              >
                <option value="">Select Court Level</option>
                <option value="District">District</option>
                <option value="High Court">High Court</option>
                <option value="Supreme Court">Supreme Court</option>
              </select>

              <select
                name="status"
                value={newCase.status}
                onChange={handleChange}
                required
              >
                <option value="">Select Status</option>
                <option value="Active">Active</option>
                <option value="Pending">Pending</option>
                <option value="Closed">Closed</option>
              </select>

              <input
                type="number"
                name="amount"
                placeholder="Amount"
                value={newCase.amount}
                onChange={handleChange}
              />

              {/* ✅ Searchable dropdown for clients */}
              <Select
                options={clients.map((c) => ({
                  value: c.id,
                  label: `${c.name} — ${c.email}`,
                }))}
                value={
                  clients.find((c) => c.id === Number(newCase.clientId))
                    ? {
                        value: Number(newCase.clientId),
                        label: clients.find(
                          (c) => c.id === Number(newCase.clientId)
                        ).name,
                      }
                    : null
                }
                onChange={(selected) =>
                  setNewCase({
                    ...newCase,
                    clientId: selected ? selected.value : "",
                  })
                }
                isClearable
                placeholder="Select Client"
              />

              <textarea
                name="description"
                placeholder="Description"
                value={newCase.description}
                onChange={handleChange}
              />

              <div style={{ display: "flex", gap: 8 }}>
                <button type="submit">
                  {editCaseId ? "Update Case" : "Save Case"}
                </button>
                <button
                  type="button"
                  className="close-btn"
                  onClick={() => setShowModal(false)}
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ✅ Cases Table */}
      <div className="cases-table">
        {cases.length === 0 ? (
          <p>No cases found.</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Case No</th>
                <th>Title</th>
                <th>Type</th>
                <th>Court Level</th>
                <th>Status</th>
                <th>Amount</th>
                <th>Client</th>
                <th>Description</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {cases.map((c) => (
                <tr key={c.id}>
                  <td>{c.caseNumber}</td>
                  <td>{c.caseTitle}</td>
                  <td>{c.caseType}</td>
                  <td>{c.courtLevel}</td>
                  <td>
                    <span className={`status ${c.status.toLowerCase()}`}>
                      {c.status}
                    </span>
                  </td>
                  <td>{c.amount}</td>
                  <td>{c.client?.name || "N/A"}</td>
                  <td>{c.description}</td>
                  <td>
                    <button onClick={() => handleEdit(c)}>Edit</button>
                    <button onClick={() => handleDelete(c.id)}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

export default Cases;
