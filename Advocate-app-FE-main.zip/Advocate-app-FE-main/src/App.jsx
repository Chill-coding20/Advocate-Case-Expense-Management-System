import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import Homepage from "./pages/Homepage.jsx";
import Login from "./pages/Login.jsx";
import Signup from "./pages/Signup.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import Cases from "./pages/Cases.jsx";
import CalendarPage from "./pages/CalendarPage.jsx"; // ✅ new import for event calendar

import { isTokenExpired, logoutAndRedirect } from "./utils/auth.jsx"; // ✅ token helper

// ---------------- Protected Route Component ----------------
function ProtectedRoute({ children }) {
  const token = localStorage.getItem("token");

  // If no token or expired → auto logout & redirect
  if (!token || isTokenExpired(token)) {
    logoutAndRedirect();
    return null; // stop rendering this route
  }

  // Otherwise allow access
  return children;
}

// ---------------- App Component ----------------
function App() {
  return (
    <Router>
      <Routes>
        {/* Public Routes */}
        <Route path="/" element={<Homepage />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />

        {/* ✅ Protected: Dashboard */}
        <Route
          path="/dashboard/*"
          element={
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          }
        />

        {/* ✅ Protected: Case Management */}
        <Route
          path="/cases"
          element={
            <ProtectedRoute>
              <Cases />
            </ProtectedRoute>
          }
        />

        {/* ✅ Protected: Calendar / Events */}
        <Route
          path="/calendar"
          element={
            <ProtectedRoute>
              <CalendarPage />
            </ProtectedRoute>
          }
        />

        {/* ✅ Fallback: Redirect unknown paths */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  );
}

export default App;
