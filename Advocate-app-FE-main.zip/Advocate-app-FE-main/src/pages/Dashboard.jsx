import React, { useEffect, useState, useRef } from "react";
import { useNavigate, NavLink, Routes, Route } from "react-router-dom";
import "../assets/styles/Dashboard.css";
import axios from "axios";

// ✅ Module imports
import Cases from "./Cases.jsx";
import Clients from "./Clients.jsx";
import Expenses from "./Expenses.jsx";
import CalendarPage from "./CalendarPage.jsx";

export default function Dashboard() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [darkMode, setDarkMode] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const [showNotifications, setShowNotifications] = useState(false);
  const [stats, setStats] = useState({ cases: 0, clients: 0, expenses: 0 });
  const [newNotificationCount, setNewNotificationCount] = useState(0);

  // 🔊 Sound alert ref
  const audioRef = useRef(null);
  const previousNotifications = useRef([]);

  // ✅ Logout function
  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("email");
    alert("Logged out successfully!");
    navigate("/login");
  };

  // ✅ Toggle dark mode
  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    document.body.classList.toggle("dark-mode", !darkMode);
  };

  // ✅ Authentication check
  useEffect(() => {
    const token = localStorage.getItem("token");
    const storedEmail = localStorage.getItem("email");

    if (!token) {
      navigate("/login");
    } else {
      setEmail(storedEmail || "");
    }
  }, [navigate]);

  // ✅ Fetch dashboard statistics
  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) return;

    const fetchStats = async () => {
      try {
        const [casesRes, clientsRes, expensesRes] = await Promise.all([
          axios.get("http://localhost:8080/api/cases/my-cases", {
            headers: { Authorization: `Bearer ${token}` },
          }),
          axios.get("http://localhost:8080/api/clients/my-clients", {
            headers: { Authorization: `Bearer ${token}` },
          }),
          axios.get("http://localhost:8080/api/expenses/my-expenses", {
            headers: { Authorization: `Bearer ${token}` },
          }),
        ]);

        setStats({
          cases: casesRes.data.length,
          clients: clientsRes.data.length,
          expenses: expensesRes.data.length,
        });
      } catch (err) {
        console.error("Error fetching dashboard stats:", err);
      }
    };

    fetchStats();
  }, []);

  // ✅ Fetch notifications from backend
  const fetchNotifications = async () => {
    const token = localStorage.getItem("token");
    if (!token) return;

    try {
      const res = await axios.get("http://localhost:8080/api/events/upcoming", {
        headers: { Authorization: `Bearer ${token}` },
      });

      const fetched = res.data || [];

      // 🔔 Play sound if new notifications appear
      if (
        previousNotifications.current.length > 0 &&
        fetched.length > previousNotifications.current.length
      ) {
        setNewNotificationCount(
          fetched.length - previousNotifications.current.length
        );
        if (audioRef.current) {
          audioRef.current.play().catch(() => console.warn("Audio play blocked"));
        }
      }

      previousNotifications.current = fetched;
      setNotifications(fetched);
    } catch (err) {
      console.error("Error fetching notifications:", err);
    }
  };

  // ✅ Auto-refresh notifications every 60 seconds
  useEffect(() => {
    fetchNotifications();
    const interval = setInterval(fetchNotifications, 60000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className={`dashboard-root ${darkMode ? "dark" : ""}`}>
      {/* 🔊 Notification Sound */}
      <audio ref={audioRef} src="/notification.mp3" preload="auto" />

      {/* ================== SIDEBAR ================== */}
      <aside className="left-sidebar">
        <div className="brand">
          <div className="brand-logo">⚖️</div>
          <div>
            <div className="brand-name">Advocate-System</div>
            <div className="brand-sub">Practice Manager</div>
          </div>
        </div>

        <nav className="nav">
          <ul>
            <li>
              <NavLink
                to="/dashboard"
                end
                className={({ isActive }) =>
                  isActive ? "nav-link active" : "nav-link"
                }
              >
                Dashboard
              </NavLink>
            </li>

            <li>
              <NavLink
                to="/dashboard/cases"
                className={({ isActive }) =>
                  isActive ? "nav-link active" : "nav-link"
                }
              >
                Cases
              </NavLink>
            </li>

            <li>
              <NavLink
                to="/dashboard/clients"
                className={({ isActive }) =>
                  isActive ? "nav-link active" : "nav-link"
                }
              >
                Clients
              </NavLink>
            </li>

            <li>
              <NavLink
                to="/dashboard/expenses"
                className={({ isActive }) =>
                  isActive ? "nav-link active" : "nav-link"
                }
              >
                Expenses
              </NavLink>
            </li>

            <li>
              <NavLink
                to="/dashboard/calendar"
                className={({ isActive }) =>
                  isActive ? "nav-link active" : "nav-link"
                }
              >
                Calendar
              </NavLink>
            </li>

            <li>
              <NavLink
                to="/dashboard/documents"
                className={({ isActive }) =>
                  isActive ? "nav-link active" : "nav-link"
                }
              >
                Documents
              </NavLink>
            </li>

            <li>
              <NavLink
                to="/dashboard/settings"
                className={({ isActive }) =>
                  isActive ? "nav-link active" : "nav-link"
                }
              >
                Settings
              </NavLink>
            </li>

            <li onClick={handleLogout} style={{ cursor: "pointer", color: "red" }}>
              Logout
            </li>
          </ul>
        </nav>
      </aside>

      {/* ================== MAIN AREA ================== */}
      <main className="main-area">
        {/* ====== TOPBAR ====== */}
        <header className="topbar">
          <div className="top-left">
            <h2>Dashboard</h2>
            <div className="subtle">Overview & quick actions</div>
          </div>

          <div className="top-right">
            {/* 🔔 Notification Bell */}
            <button
              className="icon-btn"
              onClick={() => {
                setShowNotifications(!showNotifications);
                setNewNotificationCount(0);
              }}
            >
              🔔
              {notifications.length > 0 && (
                <span className="notif-badge">
                  {newNotificationCount > 0
                    ? `+${newNotificationCount}`
                    : notifications.length}
                </span>
              )}
            </button>

            {/* 🌗 Dark Mode */}
            <button className="icon-btn" onClick={toggleDarkMode}>
              {darkMode ? "🌞" : "🌙"}
            </button>

            <span className="user-email">{email}</span>

            {/* Dropdown Notifications */}
            {showNotifications && (
              <div className="notifications-dropdown">
                <h4>Upcoming Events</h4>
                {notifications.length > 0 ? (
                  notifications.map((n, i) => (
                    <div key={i} className="notification-item">
                      <strong>{n.title}</strong>
                      <div>
                        📅 {n.date} — <em>{n.eventType}</em>
                      </div>
                      <p>{n.description}</p>
                    </div>
                  ))
                ) : (
                  <p>No upcoming events.</p>
                )}
              </div>
            )}
          </div>
        </header>

        {/* ====== MAIN CONTENT ====== */}
        <section className="content-placeholder">
          <Routes>
            <Route
              path="/"
              element={
                <div style={{ padding: "20px" }}>
                  <h3>
                    Welcome, <strong>{email}</strong> 👋
                  </h3>
                  <div className="stats-wrapper">
                    <div className="stat-card">
                      <h4>Total Cases</h4>
                      <p>{stats.cases}</p>
                    </div>
                    <div className="stat-card">
                      <h4>Total Clients</h4>
                      <p>{stats.clients}</p>
                    </div>
                    <div className="stat-card">
                      <h4>Total Expenses</h4>
                      <p>₹{stats.expenses}</p>
                    </div>
                  </div>
                  <p style={{ color: "#666", marginTop: "20px" }}>
                    Use the sidebar to manage cases, clients, expenses, and view
                    your hearing or meeting schedule on the calendar.
                  </p>
                </div>
              }
            />
            <Route path="/cases" element={<Cases />} />
            <Route path="/clients" element={<Clients />} />
            <Route path="/expenses" element={<Expenses />} />
            <Route path="/calendar" element={<CalendarPage />} />
          </Routes>
        </section>
      </main>
    </div>
  );
}
