package advocate.com.advocate_app.repository;

import advocate.com.advocate_app.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Date;

@Repository
public interface ClientPaymentRepository extends JpaRepository<ClientPayment, Long> {
    List<ClientPayment> findByAdvocate(Advocate advocate);
    List<ClientPayment> findByCaseEntity(CaseEntity caseEntity);
    List<ClientPayment> findByPaymentDateBetween(Date start, Date end);
}
