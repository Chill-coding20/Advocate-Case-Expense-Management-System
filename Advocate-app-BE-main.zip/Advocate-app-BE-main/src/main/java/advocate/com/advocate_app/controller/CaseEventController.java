package advocate.com.advocate_app.controller;

import advocate.com.advocate_app.entity.CaseEventEntity;
import advocate.com.advocate_app.security.JwtUtil;
import advocate.com.advocate_app.service.CaseEventService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/events")
@CrossOrigin(origins = "http://localhost:5173")
public class CaseEventController {

    @Autowired
    private CaseEventService caseEventService;

    @PostMapping("/create")
    public ResponseEntity<?> createEvent(@RequestHeader("Authorization") String token,
                                         @RequestBody CaseEventEntity event) {
        try {
            String email = JwtUtil.extractEmail(token.substring(7));
            return ResponseEntity.ok(caseEventService.createEvent(email, event));
        } catch (Exception e) {
            return ResponseEntity.status(500).body("❌ Error creating event: " + e.getMessage());
        }
    }

    @GetMapping("/my-events")
    public ResponseEntity<?> getMyEvents(@RequestHeader("Authorization") String token) {
        try {
            String email = JwtUtil.extractEmail(token.substring(7));
            List<CaseEventEntity> events = caseEventService.getMyEvents(email);
            return ResponseEntity.ok(events);
        } catch (Exception e) {
            return ResponseEntity.status(500).body("❌ Error fetching events: " + e.getMessage());
        }
    }

    @GetMapping("/today")
    public ResponseEntity<?> getTodayEvents(@RequestHeader("Authorization") String token) {
        try {
            String email = JwtUtil.extractEmail(token.substring(7));
            List<CaseEventEntity> events = caseEventService.getEventsByDate(email, LocalDate.now());
            return ResponseEntity.ok(events);
        } catch (Exception e) {
            return ResponseEntity.status(500).body("❌ Error fetching today's events: " + e.getMessage());
        }
    }

    @GetMapping("/upcoming")
    public ResponseEntity<?> getUpcomingEvents(@RequestHeader("Authorization") String token) {
        try {
            String email = JwtUtil.extractEmail(token.substring(7));
            return ResponseEntity.ok(caseEventService.getUpcomingEvents(email));
        } catch (Exception e) {
            return ResponseEntity.status(500).body("❌ Error fetching upcoming events: " + e.getMessage());
        }
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> deleteEvent(@RequestHeader("Authorization") String token,
                                         @PathVariable Long id) {
        try {
            String email = JwtUtil.extractEmail(token.substring(7));
            caseEventService.deleteEvent(email, id);
            return ResponseEntity.ok("✅ Event deleted successfully");
        } catch (Exception e) {
            return ResponseEntity.status(500).body("❌ Error deleting event: " + e.getMessage());
        }
    }
}
