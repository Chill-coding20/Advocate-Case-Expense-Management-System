package advocate.com.advocate_app.controller;

import advocate.com.advocate_app.entity.ClientPayment;
import advocate.com.advocate_app.service.ClientPaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.List;

@RestController
@RequestMapping("/api/payments")
@CrossOrigin(origins = "http://localhost:5173")
public class ClientPaymentController {

    @Autowired
    private ClientPaymentService paymentService;

    @PostMapping("/create")
    public ClientPayment createPayment(@RequestBody ClientPayment payment) {
        return paymentService.createPayment(payment);
    }

    @GetMapping("/case/{caseId}")
    public List<ClientPayment> getCasePayments(@PathVariable Long caseId) {
        return paymentService.getPaymentsByCase(caseId);
    }

    @GetMapping("/today")
    public Map<String, Object> getTodaySummary() {
        return paymentService.getTodaySummary();
    }

    @GetMapping("/monthly")
    public Map<String, Object> getMonthlySummary(@RequestParam int year, @RequestParam int month) {
        return paymentService.getMonthlySummary(year, month);
    }
}
